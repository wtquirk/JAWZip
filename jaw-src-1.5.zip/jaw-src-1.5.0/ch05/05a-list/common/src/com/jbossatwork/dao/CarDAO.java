package com.jbossatwork.dao;

import java.util.*;
import com.jbossatwork.dto.*;

public interface CarDAO 
{
    public List findAll(); 
}