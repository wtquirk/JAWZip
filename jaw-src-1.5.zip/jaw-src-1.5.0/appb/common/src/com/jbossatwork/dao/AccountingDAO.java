package com.jbossatwork.dao;

import java.util.*;
import com.jbossatwork.dto.*;

public interface AccountingDAO
{
    public void create(AccountingDTO accountingData);
}