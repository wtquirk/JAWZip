package com.jbossatwork.dao;

import java.util.*;

public interface CarDAO 
{
    public List findAll(); 
}